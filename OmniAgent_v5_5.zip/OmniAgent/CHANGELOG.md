# OmniNode 5.5 — changelog

- **Fixed (critical):** the v5.4 inserts (core-only graph, catalog, corepure) were placed inside the `lock` string of the island script, so the whole Dynamic Island script was a syntax error. The string is restored and the blocks moved to the end of the page.
- Island shapes: capsule / drop (water-drop notch, like budget phones) / dot, with size setting.
- Move the island anywhere (sliders X/Y, drag with finger in the app, or drag over other apps via the native window); position is saved.
- Core and island are separate: `startOverlay` only starts the island; the permission wizard respects your choices; expanding one collapses the other.
- Activities screen (Island → Main → Activities): Compact / Expanded, Enable Activity, Geometry & Sizes (width, height, top offset, radius) and features per activity, reset per activity / all.
- Island look redone after the videos: glass expanded cards with a tint gradient and rim, music card (big cover, thin progress bar with times, round play), stopwatch/timer cards with round blue/red buttons and line icons, 4-bar equalizer, SVG icons in the Activities chips.
- Everything from 5.3 and 5.4 is kept (agent app resolution, model auto-resume, catalog, graph-only core...). The classic music / stopwatch / timer cards stay available: Island → Appearance → «Style from the video» (off = classic).
- Glass Layer: blur, refraction, reflection, rim, shadow, tint, glass on cards / buttons, performance modes.

# OmniNode 5.4 — changelog

- Agent: exact app resolution (MAX no longer opens Telegram/Yandex): known packages first, then exact/whole-word label match; "open X" fast path; open is verified against the foreground package.
- Models 0.5 / 1.5 / 3: auto-resume (6 retries, waits for network), WakeLock + foreground keep-alive while downloading, runtime import fallback, clear WebGPU errors.
- Island: window is anchored to the camera cutout (X and Y); width/height/offset settings drive the native window; wider screen-recorder detection.
- Core: main screen shows only the graph (RU / mic / gear buttons hidden; long-press "OMNINODE" opens settings).
- Catalog: MAX and many more messengers, games (Brawl Stars, Stumble Guys, HSR, ZZZ, Wuthering Waves...) and apps; installed apps launch directly by package.

# OmniNode 5.3 — changelog

## Changed
- **AI works like the previous version again.** Free engines first (Pollinations, Pollinations gen — no download, no key), then on-device Qwen
  (Light 0.5B / Medium 1.5B / Heavy 3B) that downloads directly with the "Download" button in AI settings, then your own API keys.
  The "AI models" manager no longer replaces the download buttons; its button and its node in the AI branch are removed.
- **Dynamic Island → Preview:** the extra "Остров+" block (Face ID, sound, silent, vibration, volume, Wi-Fi, mic, camera) is removed.
  All previews stay in the main list (charging, low battery, silent, vibrate, DND, Wi-Fi, VPN, hotspot, Face ID, lock...).

## Fixed
- Russian mode: Live Activities island texts (Charging, Silent, Vibrate, On/Off, Offline...), the new settings rows, preview buttons,
  startup banner, error/recovery screen and "What's new" are now translated.
- Qwen download card in English mode: the progress card could not detect "Model downloaded" / "Download failed" after the UI text was translated.

## Fixed
- **Black screen "Нарушена целостность приложения" after tapping the core.** Root cause: in the collapsed-core overlay the CSS rule
  `html.core28c body > :not(#g) {display:none!important}` hid the copyright footer `#cr2`; the integrity guard checked it every 4 s,
  treated "hidden" as tampering and replaced the whole page. The footer and the self-destructing check are gone. Copyright stays in the
  file header, the console banner and About → What's new.
- Fake status removed: the startup banner "Qwen готов" was shown even with no model loaded. It now reflects the real state.
- Old "Remove model" only cleared a flag and left the files on the device. Models are now deleted from the cache for real.
- Silent model download over mobile data / Data Saver at startup is now blocked.
- Graph nodes overlapping each other (11–20 touching pairs on common phone sizes → 0 on 360×780, 390×844, 412×915, 320×568, 800×1280).

## Added
- Dynamic Island **Live Activities look** (Island → Appearance → "Live Activities look"): tinted outline + glow per activity, animated icons,
  call / timer / stopwatch / recording / music / navigation / charging / low battery / headphones / silent·vibrate / Wi-Fi / Do Not Disturb /
  VPN / hotspot / Face ID scan → unlock. New previews in Island → Preview.
- **AI models manager** (AI branch → "AI models", or AI settings → "On-device models"): AI Model 0.5 / 1.5 / 3 (Qwen2.5 q4f16_1 via WebLLM).
  Device check (WebGPU, RAM, free storage, network), real progress, cancel, cache verification, activate with self-test, release memory, delete.
  Model sources are configurable: `window.OMNI_MODELS_CONFIG` / `__m29.register()`.
- Download progress is shown in the island.
- Error boundary + recovery screen (Reload / Reset graph layout) instead of a blank screen; log in `localStorage.omni29err`.
- i18n engine (`window.I18N`): English is the default; RU stays available; more languages via `I18N.register(lang, dict)`.
  Dictionary source: `docs/i18n_en.json` (1 212 entries). `I18N.missing()` lists untranslated text at runtime.
- Speech recognition / TTS language follows the UI language.

## Known limits
- The voice/text agent understands **Russian commands only** (`открой`, `запусти`, `включи`…). Example commands are therefore kept in Russian.
- Real triggers for DND / VPN / hotspot pills need native emitters (`OmniIsland.sys('dnd'|'vpn'|'hotspot', …)`); previews work now.
- Long-tail Russian strings (mostly the agent's example commands and brand monograms) remain.
- Model downloads were tested against a simulated WebLLM module; a real download needs a device with WebGPU and network.
