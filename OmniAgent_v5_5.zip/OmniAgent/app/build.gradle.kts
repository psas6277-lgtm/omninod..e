plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="com.omninode.app";compileSdk=34
defaultConfig{applicationId="com.omninode.app";minSdk=26;targetSdk=34;versionCode=6;versionName="5.5"}
buildTypes{release{isMinifyEnabled=false;signingConfig=signingConfigs.getByName("debug")}}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}
lint{abortOnError=false;checkReleaseBuilds=false}}
dependencies{implementation("androidx.core:core-ktx:1.12.0");implementation("androidx.webkit:webkit:1.10.0")}
