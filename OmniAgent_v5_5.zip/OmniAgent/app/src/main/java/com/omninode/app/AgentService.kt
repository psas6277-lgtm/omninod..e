package com.omninode.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Элемент экрана, который видит агент. */
class Nd(
    val node: AccessibilityNodeInfo,
    val label: String,
    val r: Rect,
    val click: Boolean,
    val edit: Boolean,
    val scroll: Boolean,
    val pwd: Boolean,
    val kind: String
)

/** Снимок экрана: пакет приложения, текстовое описание для ИИ и список элементов. */
class Screen(val pkg: String, val text: String, val nodes: List<Nd>)

class AgentService : AccessibilityService() {
    companion object {
        @Volatile var inst: AgentService? = null
        @Volatile var lastPkg: String = ""
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: android.content.Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString() ?: return
            if (p == lastPkg) return
            if (p == packageName || p.contains("systemui") || p.contains("inputmethod") || p.contains("keyboard")) return
            lastPkg = p
            try { OverlayService.inst?.onForeground(p) } catch (ex: Exception) {}
        }
    }

    // ---------- чтение экрана ----------

    private fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 60 || out.size > 1500) return
            out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(rootInActiveWindow, 0)
        return out
    }

    private fun label(n: AccessibilityNodeInfo): String = (n.text ?: n.contentDescription ?: "").toString()

    private fun deep(n: AccessibilityNodeInfo, d: Int): String {
        if (d > 3) return ""
        val parts = ArrayList<String>()
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val s = label(c)
            if (s.isNotBlank()) parts.add(s) else {
                val x = deep(c, d + 1)
                if (x.isNotBlank()) parts.add(x)
            }
            if (parts.size >= 3) break
        }
        return parts.joinToString(" ")
    }

    /** Подробное описание экрана для ИИ-агента. */
    fun describeScreen(max: Int = 90): Screen {
        val root = rootInActiveWindow
        val out = ArrayList<Nd>()
        val seen = HashSet<String>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 60 || out.size >= max) return
            if (n.isVisibleToUser) {
                val own = label(n)
                var lab = if (own.isNotBlank()) own else if (n.isClickable) deep(n, 0) else ""
                if (lab.isBlank() && (n.isClickable || n.isEditable)) {
                    lab = n.viewIdResourceName?.substringAfter('/') ?: ""
                }
                val edit = n.isEditable
                val click = n.isClickable
                val scr = n.isScrollable
                if (lab.isNotBlank() || edit || click || scr) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    if (r.width() > 0 && r.height() > 0) {
                        val kind = if (edit) "поле" else if (click) "кнопка" else if (scr) "список" else "текст"
                        val key = kind + lab + r.left + "," + r.top
                        if (seen.add(key)) out.add(Nd(n, lab.take(80), r, click, edit, scr, n.isPassword, kind))
                    }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val sb = StringBuilder()
        for ((i, x) in out.withIndex()) {
            sb.append('#').append(i).append(' ').append(x.kind)
            if (x.pwd) sb.append("(пароль)")
            if (x.label.isNotBlank()) sb.append(" «").append(x.label.replace('\n', ' ')).append('»')
            sb.append('\n')
        }
        val pkg = root?.packageName?.toString() ?: lastPkg
        return Screen(pkg, sb.toString().trim(), out)
    }

    /** Старый компактный формат (для совместимости со старым JS-слоем). */
    fun screenText(): String = nodes().mapNotNull {
        val s = label(it); if (s.isBlank()) null else if (it.isClickable) "[$s]" else s
    }.distinct().take(120).joinToString(" | ")

    // ---------- действия над элементами ----------

    fun clickNode(nd: Nd): Boolean {
        var c: AccessibilityNodeInfo? = nd.node
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            depth++
        }
        return tapAt(nd.r.exactCenterX(), nd.r.exactCenterY())
    }

    fun tapText(t: String): Boolean {
        val q = t.lowercase().trim()
        if (q.isEmpty()) return false
        val all = nodes()
        // сначала точное совпадение, потом «содержит»
        val exact = all.firstOrNull { label(it).lowercase().trim() == q }
        val hit = exact ?: all.firstOrNull { label(it).lowercase().contains(q) } ?: return false
        var c: AccessibilityNodeInfo? = hit
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            depth++
        }
        val r = Rect(); hit.getBoundsInScreen(r)
        return if (r.width() > 0) tapAt(r.exactCenterX(), r.exactCenterY()) else false
    }

    fun typeText(t: String): Boolean = typeInto(null, t)

    fun typeInto(nd: Nd?, t: String): Boolean {
        val all = nodes()
        val f = nd?.node ?: all.firstOrNull { it.isEditable && it.isFocused } ?: all.firstOrNull { it.isEditable } ?: return false
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        f.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return true
        // запасной путь — вставка из буфера обмена
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("omni", t))
            f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (e: Exception) { false }
    }

    fun focusedIsPassword(): Boolean = nodes().any { it.isEditable && it.isFocused && it.isPassword }

    /** Enter / «Поиск» / «Отправить» на клавиатуре. */
    fun imeEnter(): Boolean {
        val all = nodes()
        val f = all.firstOrNull { it.isEditable && it.isFocused } ?: all.firstOrNull { it.isEditable }
        if (f != null && Build.VERSION.SDK_INT >= 30) {
            try {
                if (f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
            } catch (e: Exception) {}
        }
        for (s in listOf("Найти", "Поиск", "Search", "Go", "Отправить", "Send")) if (tapText(s)) return true
        return false
    }

    fun scroll(down: Boolean): Boolean {
        val n = nodes().firstOrNull { it.isScrollable } ?: return swipe(if (down) "down" else "up")
        return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    // ---------- жесты ----------

    fun tapAt(x: Float, y: Float, dur: Long = 60): Boolean {
        return try {
            val p = Path(); p.moveTo(x, y)
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) { false }
    }

    fun longPressAt(x: Float, y: Float): Boolean = tapAt(x, y, 900)

    /** dir — куда «листать»: down = содержимое едет вверх (палец движется снизу вверх). */
    fun swipe(dir: String): Boolean {
        return try {
            val dm = resources.displayMetrics
            val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
            val p = Path()
            when (dir) {
                "down" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
                "up" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
                "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
                "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
                else -> return false
            }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 320)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) { false }
    }

    fun global(action: Int): Boolean = try { performGlobalAction(action) } catch (e: Exception) { false }

    // ---------- быстрые настройки (Wi-Fi, Bluetooth, режим полёта и т.д.) ----------

    private fun tileOn(n: AccessibilityNodeInfo): Boolean? {
        var s = ""
        if (Build.VERSION.SDK_INT >= 30) s += " " + (n.stateDescription ?: "")
        s += " " + (n.contentDescription ?: "") + " " + (n.text ?: "")
        s = s.lowercase()
        val off = Regex("выкл|отключ|\\boff\\b").containsMatchIn(s)
        val on = Regex("\\bвкл|включ|\\bon\\b").containsMatchIn(s)
        return if (off && !on) false else if (on && !off) true else if (n.isChecked) true else null
    }

    /** Открывает шторку, находит плитку по названию и при необходимости нажимает. Вызывать только не из главного потока. */
    fun toggleTile(names: List<String>, want: Boolean?): String {
        if (!global(GLOBAL_ACTION_QUICK_SETTINGS)) return "не удалось открыть шторку"
        try { Thread.sleep(1000) } catch (e: Exception) {}
        var tile: AccessibilityNodeInfo? = null
        for (attempt in 0..3) {
            tile = nodes().firstOrNull { n ->
                val l = label(n).lowercase()
                l.isNotBlank() && names.any { l.contains(it) } && (n.isClickable || n.parent?.isClickable == true)
            }
            if (tile != null) break
            swipe("left")
            try { Thread.sleep(500) } catch (e: Exception) {}
        }
        val t = tile
        if (t == null) { global(GLOBAL_ACTION_BACK); return "плитка не найдена" }
        val st = tileOn(t)
        var msg = "готово"
        if (want != null && st != null && st == want) {
            msg = "уже " + (if (want) "включено" else "выключено")
        } else {
            var c: AccessibilityNodeInfo? = t
            var ok = false
            var d = 0
            while (c != null && d < 4) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { ok = true; break }; c = c.parent; d++ }
            if (!ok) {
                val r = Rect(); t.getBoundsInScreen(r)
                tapAt(r.exactCenterX(), r.exactCenterY())
            }
        }
        try { Thread.sleep(700) } catch (e: Exception) {}
        global(GLOBAL_ACTION_BACK)
        return msg
    }
}
