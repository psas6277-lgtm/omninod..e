package com.omninode.app
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.os.Bundle
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject

class Bridge(private val c: Context, private val web: WebView) {
    private var sr: SpeechRecognizer? = null
    private fun js(code: String) { Handler(Looper.getMainLooper()).post { web.evaluateJavascript(code, null) } }
    private val h = Handler(Looper.getMainLooper())
    init {
        Speaker.init(c)
        Speaker.onDone = { id -> OverlayService.emit("window.__omniTts&&window.__omniTts('done'," + JSONObject.quote(id) + ")") }
    }
    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); OverlayService.inst?.coreCollapse(); c.startActivity(i) }
    private fun pkgByName(name: String): String? = Apps.find(c, name)
    private var dlLock: android.os.PowerManager.WakeLock? = null
    /** Держит загрузку модели живой в фоне: WakeLock, foreground-сервис и таймеры WebView не засыпают. */
    @JavascriptInterface fun keepAlive(on: Boolean) {
        h.post {
            try {
                if (on) {
                    if (dlLock == null) {
                        val pm = c.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        dlLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "omninode:modeldl").apply { setReferenceCounted(false) }
                    }
                    if (dlLock?.isHeld != true) dlLock?.acquire(90 * 60 * 1000L)
                    try { c.startForegroundService(Intent(c, OverlayService::class.java)) } catch (e: Exception) {}
                    try { web.resumeTimers() } catch (e: Exception) {}
                } else {
                    if (dlLock?.isHeld == true) dlLock?.release()
                }
            } catch (e: Exception) {}
        }
    }
    @JavascriptInterface fun cutout(): String = OverlayService.inst?.islandCutout() ?: "0,0,0"
    /** Запуск установленного приложения по пакету; false — не установлено (JS откроет магазин). */
    @JavascriptInterface fun openPkg(p: String): Boolean {
        val i = try { c.packageManager.getLaunchIntentForPackage(p.trim()) } catch (e: Exception) { null } ?: return false
        go(i); return true
    }
    @JavascriptInterface fun isNative() = true
    @JavascriptInterface fun island(t: String) { OverlayService.inst?.setIsland(t) }
    @JavascriptInterface fun hasAccess() = AgentService.inst != null
    @JavascriptInterface fun hasOverlay() = Settings.canDrawOverlays(c)
    @JavascriptInterface fun openAccessSettings() { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    @JavascriptInterface fun openOverlaySettings() { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) }
    @JavascriptInterface fun startOverlay(): Boolean {
        if (!Settings.canDrawOverlays(c)) { openOverlaySettings(); return false }
        Prefs.set(c, "island_on", true)   // только остров: ядро включается отдельной кнопкой
        return Modes.apply(c)
    }
    @JavascriptInterface fun stopOverlay() { Prefs.set(c, "island_on", false); Modes.apply(c) }
    /** Режим перемещения острова пальцем (поверх любых приложений). */
    @JavascriptInterface fun islandMove(on: Boolean) { OverlayService.inst?.islandMove(on) }
    @JavascriptInterface fun openApp(name: String): Boolean {
        val p = pkgByName(name) ?: return false
        val i = c.packageManager.getLaunchIntentForPackage(p) ?: return false
        go(i); return true
    }
    @JavascriptInterface fun closeApp(name: String): Boolean {
        val p = pkgByName(name) ?: return false
        go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")))
        h.postDelayed({ val a = AgentService.inst
            if (a != null) { if (!(a.tapText("Остановить") || a.tapText("Force stop") || a.tapText("Принудительно")))  {} }
        }, 1400)
        h.postDelayed({ val a = AgentService.inst; if (a != null) { a.tapText("ОК") || a.tapText("OK") || a.tapText("Остановить") } }, 2400)
        h.postDelayed({ AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }, 3200)
        return true
    }
    @JavascriptInterface fun tapText(t: String) = AgentService.inst?.tapText(t) ?: false
    @JavascriptInterface fun typeText(t: String) = AgentService.inst?.typeText(t) ?: false
    @JavascriptInterface fun scroll(down: Boolean) = AgentService.inst?.scroll(down) ?: false
    @JavascriptInterface fun screenText() = AgentService.inst?.screenText() ?: ""
    @JavascriptInterface fun back() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    @JavascriptInterface fun home() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    @JavascriptInterface fun recents() = AgentService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
    @JavascriptInterface fun openUrl(u: String) { try { go(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) {} }

    @JavascriptInterface fun listen(lang: String) {
        Handler(Looper.getMainLooper()).post {
            try {
                sr?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(c); sr = r
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onError(e: Int) { js("window.__omniVoice&&window.__omniVoice('error','')") }
                    override fun onResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                        js("window.__omniVoice&&(window.__omniVoice('final'," + JSONObject.quote(t) + "),window.__omniVoice('end',''))")
                    }
                    override fun onPartialResults(b: Bundle?) {
                        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                        if (t.isNotEmpty()) js("window.__omniVoice&&window.__omniVoice('interim'," + JSONObject.quote(t) + ")")
                    }
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                r.startListening(i)
            } catch (e: Exception) { js("window.__omniVoice&&window.__omniVoice('error','')") }
        }
    }
    @JavascriptInterface fun stopListen() { Handler(Looper.getMainLooper()).post { try { sr?.stopListening() } catch (e: Exception) {} } }
    @JavascriptInterface fun volume(dir: String) {
        val a = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_TOGGLE_MUTE }
        a.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
    }
    @JavascriptInterface fun torch(on: Boolean): Boolean {
        return try { val m = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager; m.setTorchMode(m.cameraIdList[0], on); true } catch (e: Exception) { false }
    }
    @JavascriptInterface fun panel(kind: String) {
        val a = if (android.os.Build.VERSION.SDK_INT >= 29) (if (kind == "volume") Settings.Panel.ACTION_VOLUME else Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Settings.ACTION_WIFI_SETTINGS
        go(Intent(a))
    }

    @JavascriptInterface fun coreCollapse() { OverlayService.inst?.coreCollapse() }
    @JavascriptInterface fun setCoreColor(hex: String) { OverlayService.inst?.setCoreColor(hex) }
    @JavascriptInterface fun showPanel() { OverlayService.inst?.showPanel(true) }
    @JavascriptInterface fun hidePanel() { OverlayService.inst?.showPanel(false) }
    @JavascriptInterface fun batteryOpt() {
        val pm = c.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (!pm.isIgnoringBatteryOptimizations(c.packageName)) go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)))
    }

    @JavascriptInterface fun hasNotifAccess(): Boolean = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    @JavascriptInterface fun openNotifAccess() { go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }

    @JavascriptInterface fun timer(sec: Int, label: String) { OverlayService.inst?.startTimer(sec, label) }
    @JavascriptInterface fun demo(kind: String) { OverlayService.inst?.demo(kind) }

    @JavascriptInterface fun orb(t: String) { OverlayService.inst?.orb(t) }
    @JavascriptInterface fun stopwatch(cmd: String) { OverlayService.inst?.stopwatch(cmd) }
    @JavascriptInterface fun setIslandStyle(style: Int, rim: Int, blur: Int, grad: Boolean, spring: Int) {
        c.getSharedPreferences("omni", Context.MODE_PRIVATE).edit().putInt("isl_style", style).putInt("isl_rim", rim).putInt("isl_blur", blur).putBoolean("isl_grad", grad).putInt("isl_spring", spring).apply()
        OverlayService.inst?.refreshIsland()
    }
    @JavascriptInterface fun setUnlock(kind: String) { c.getSharedPreferences("omni", Context.MODE_PRIVATE).edit().putString("unlock", kind).apply() }
    @JavascriptInterface fun islandPrefs(): String {
        val p = c.getSharedPreferences("omni", Context.MODE_PRIVATE)
        return "{\"style\":" + p.getInt("isl_style", 0) + ",\"rim\":" + p.getInt("isl_rim", 50) + ",\"blur\":" + p.getInt("isl_blur", 40) + ",\"grad\":" + p.getBoolean("isl_grad", true) + ",\"spring\":" + p.getInt("isl_spring", 14) + ",\"unlock\":\"" + p.getString("unlock", "face") + "\"}"
    }

    // ---------- протокол, который ждёт веб-часть ----------
    @JavascriptInterface fun start(): Boolean = Msg.handle(c, "start")
    @JavascriptInterface fun stop(): Boolean = Msg.handle(c, "stop")
    @JavascriptInterface fun startCore(): Boolean = Msg.handle(c, "startCore")
    @JavascriptInterface fun stopCore(): Boolean = Msg.handle(c, "stopCore")
    @JavascriptInterface fun startBg(): Boolean = Msg.handle(c, "startBg")
    @JavascriptInterface fun stopBg(): Boolean = Msg.handle(c, "stopBg")
    @JavascriptInterface fun hideInGames(): Boolean = Msg.handle(c, "hideInGames")
    @JavascriptInterface fun showInGames(): Boolean = Msg.handle(c, "showInGames")
    @JavascriptInterface fun requestOverlay(): Boolean { openOverlaySettings(); return true }

    @JavascriptInterface fun requestPerm(k: String): Boolean {
        when (k) {
            "notif" -> openNotifAccess()
            "battery" -> batteryOpt()
            "access" -> openAccessSettings()
            "mic" -> h.post { MainActivity.inst?.requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 11) }
            "cam" -> h.post { MainActivity.inst?.requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 12) }
            "autostart" -> {
                val tries = listOf(
                    "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
                    "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
                    "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
                    "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                )
                var ok = false
                for ((p, cl) in tries) {
                    try { go(Intent().setClassName(p, cl)); ok = true; break } catch (e: Exception) {}
                }
                if (!ok) go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)))
            }
            else -> return false
        }
        return true
    }

    private fun granted(p: String) = c.checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED

    @JavascriptInterface fun permStatus(): String {
        val pm = c.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        val o = JSONObject()
        o.put("overlay", Settings.canDrawOverlays(c))
        o.put("notif", hasNotifAccess())
        o.put("battery", pm.isIgnoringBatteryOptimizations(c.packageName))
        o.put("mic", granted(android.Manifest.permission.RECORD_AUDIO))
        o.put("cam", granted(android.Manifest.permission.CAMERA))
        o.put("access", AgentService.inst != null)
        return o.toString()
    }

    @JavascriptInterface fun isRunning(): String {
        val s = OverlayService.inst
        val o = JSONObject()
        o.put("core", s?.coreShown() ?: false)
        o.put("island", s?.islandShown() ?: false)
        o.put("agent", NativeAgent.isRunning)
        return o.toString()
    }

    @JavascriptInterface fun openAppInfo() { go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))) }

    // ---------- озвучка ----------
    @JavascriptInterface fun speak(text: String, lang: String, id: String) { Speaker.say(text, if (lang.isBlank()) "ru-RU" else lang, if (id.isBlank()) "u" + System.nanoTime() else id) }
    @JavascriptInterface fun stopSpeak() { Speaker.stop() }
    @JavascriptInterface fun isSpeaking(): Boolean = Speaker.speaking()

    // ---------- переключатели ----------
    @JavascriptInterface fun getPrefs(): String = Prefs.toggles(c)
    @JavascriptInterface fun setPref(k: String, v: Boolean): Boolean {
        val allowed = setOf("tts_assistant", "tts_user", "tts_agent", "confirm_pay", "hide_games")
        if (k !in allowed) return false
        Prefs.set(c, k, v)
        if (k == "hide_games") OverlayService.inst?.applyModes()
        return true
    }

    // ---------- ИИ-агент ----------
    @JavascriptInterface fun agentRun(goal: String, cfg: String): Boolean = NativeAgent.start(c, goal, cfg)
    @JavascriptInterface fun agentStop() { NativeAgent.stop() }
    @JavascriptInterface fun agentRunning(): Boolean = NativeAgent.isRunning
    @JavascriptInterface fun agentLog(): String = NativeAgent.log()

    // ---------- уведомления ----------
    @JavascriptInterface fun notifDigestText(): String = OmniNotifService.digest()
}
