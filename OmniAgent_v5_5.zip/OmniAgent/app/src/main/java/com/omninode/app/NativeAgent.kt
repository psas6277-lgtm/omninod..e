package com.omninode.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Автономный ИИ-агент. Цикл «посмотреть экран → спросить ИИ → выполнить действие» работает в отдельном потоке
 * и не зависит от WebView, поэтому продолжает работать, пока открыты другие приложения.
 *
 * Безопасность: оплата, переводы, заказы и удаление выполняются только после подтверждения пользователя
 * в нативном окне поверх приложений (если не отключено в настройках). Пароли, PIN и коды агент сам не вводит.
 */
object NativeAgent {
    @Volatile private var running = false
    @Volatile private var stopFlag = false
    private val logLines = ArrayList<String>()
    private const val MAX_STEPS = 35

    val isRunning: Boolean get() = running

    fun stop() { stopFlag = true; Speaker.stop() }

    fun log(): String = synchronized(logLines) { logLines.joinToString("\n") }

    private val RISKY = Regex(
        "(?i)(оплат|заплат|купить|купи\\b|покупк|заказать|оформить заказ|подтвердить (платеж|платёж|заказ|перевод|покупку)|" +
            "перевести|перевод[а-я]* (на|в)|отправить перевод|\\bpay\\b|pay now|buy now|place order|purchase|confirm (payment|order)|checkout|" +
            "удалить|delete|снять деньги|списать)"
    )
    private val SECRET = Regex("(?i)(пароль|password|cvv|cvc|пин-?код|\\bpin\\b|код из (смс|sms)|одноразов)")

    private val SYSTEM = """Ты — автономный агент, управляющий Android-телефоном через службу доступности.
Экран приходит списком элементов: «#N тип «текст»». На каждом шаге верни ТОЛЬКО один JSON-объект без пояснений и без markdown:
{"do":"...","arg":"...","n":0,"why":"кратко, зачем"}
Действия (do):
open — arg: ТОЧНОЕ название приложения как сказал пользователь («MAX», «Telegram», «Сбербанк», «Chrome», «YouTube») или пакет; никогда не подменяй одно приложение другим (MAX ≠ Telegram ≠ Яндекс)
url — arg: ссылка https://… (открыть в браузере)
tap — n: номер элемента из списка (или arg: точный текст кнопки)
type — arg: текст; n: номер поля (если не указан — активное поле)
enter — нажать Enter/«Поиск»/«Отправить» на клавиатуре
scroll — arg: down | up | left | right
back, home, recents, notifications
wait — arg: секунды (1–5)
say — arg: сказать пользователю вслух (задачу не завершает)
ask — пауза: попросить пользователя вручную ввести пароль/PIN/CVC/код из SMS; arg: что именно сделать
done — arg: итог для пользователя (цель достигнута)
fail — arg: почему задачу выполнить нельзя
Правила:
1. Делай по одному шагу и смотри на результат. Не повторяй действие, которое не сработало, больше 2 раз — меняй подход.
2. Для мессенджера: открой приложение → поиск (лупа) → type имени → tap по найденному контакту → tap по полю сообщения → type текста → tap «Отправить»/Send → done.
3. Пароли, PIN, CVV, коды из SMS и полные номера карт сам НЕ вводи — используй ask.
4. Оплату, перевод, заказ и удаление можно нажимать — перед такими нажатиями система сама спросит подтверждение у пользователя. Если пользователь отказал — выбери done с честным итогом.
5. Если открыт не тот экран — back. После open проверь «Текущее приложение»: оно должно соответствовать запрошенному. Если запрошенного приложения нет — fail, НЕ открывай похожее.
6. Когда цель достигнута — сразу done с коротким итогом (одно-два предложения, по-русски)."""

    // ---------- запуск ----------

    fun start(c: Context, goal: String, cfg: String?): Boolean {
        if (goal.isBlank()) return false
        val app = c.applicationContext
        Speaker.init(app)
        if (running) { emit("step", "Агент уже работает — нажми ⏹, чтобы остановить"); return false }
        if (AgentService.inst == null) {
            try { val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); app.startActivity(i) } catch (e: Exception) {}
            emit("done", "Включи «OmniNode» в Специальных возможностях Android — я открыл настройки. Потом повтори команду.")
            return false
        }
        running = true; stopFlag = false
        synchronized(logLines) { logLines.clear() }
        // сервис оверлея нужен для статуса в острове и окна подтверждения
        try { if (Settings.canDrawOverlays(app)) app.startForegroundService(Intent(app, OverlayService::class.java)) } catch (e: Exception) {}
        Thread { try { loop(app, goal, cfg) } finally { running = false; try { OverlayService.inst?.applyModes() } catch (e: Exception) {} } }.start()
        return true
    }

    // ---------- вспомогательное ----------

    private fun emit(type: String, text: String) {
        synchronized(logLines) { logLines.add(text); while (logLines.size > 80) logLines.removeAt(0) }
        try { OverlayService.emit("window.__agentEvent&&window.__agentEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(text) + ")") } catch (e: Exception) {}
    }

    private fun status(c: Context, t: String) {
        try { OverlayService.inst?.setIsland("🤖 " + t.take(46)) } catch (e: Exception) {}
        emit("step", t)
    }

    private fun finish(c: Context, text: String) {
        try { OverlayService.inst?.setIsland("✅ " + text.take(40)) } catch (e: Exception) {}
        emit("done", text)
        if (Prefs.b(c, "tts_agent", true)) Speaker.say(text)
    }

    /** Блокирующее подтверждение в окне поверх приложений. false — отказ или таймаут. */
    private fun confirm(c: Context, title: String, msg: String, yes: String, no: String): Boolean {
        val svc = OverlayService.inst ?: return false
        val latch = CountDownLatch(1)
        val res = BooleanArray(1)
        svc.confirm(title, msg, yes, no) { ok -> res[0] = ok; latch.countDown() }
        if (Prefs.b(c, "tts_agent", true)) Speaker.say(title)
        return try { latch.await(120, TimeUnit.SECONDS) && res[0] } catch (e: Exception) { false }
    }

    private fun providers(cfg: String?): List<Array<String>> {
        val out = ArrayList<Array<String>>()
        try {
            if (!cfg.isNullOrBlank()) {
                val a = JSONObject(cfg).optJSONArray("p")
                if (a != null) for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(arrayOf(o.getString("u"), o.optString("m", "openai"), o.optString("k", "")))
                }
            }
        } catch (e: Exception) {}
        if (out.isEmpty()) {
            out.add(arrayOf("https://api.llm7.io/v1/chat/completions", "gpt-4o-mini", "unused"))
            out.add(arrayOf("https://text.pollinations.ai/openai", "openai", ""))
            out.add(arrayOf("https://gen.pollinations.ai/v1/chat/completions", "openai", ""))
        }
        return out
    }

    private fun llm(cfg: String?, prompt: String): String? {
        for (p in providers(cfg)) {
            try {
                val body = JSONObject()
                body.put("model", p[1])
                body.put("temperature", 0.2)
                body.put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                val cn = URL(p[0]).openConnection() as HttpURLConnection
                cn.requestMethod = "POST"
                cn.connectTimeout = 15000
                cn.readTimeout = 40000
                cn.doOutput = true
                cn.setRequestProperty("Content-Type", "application/json")
                if (p[2].isNotBlank()) cn.setRequestProperty("Authorization", "Bearer " + p[2])
                cn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                if (cn.responseCode !in 200..299) { cn.disconnect(); continue }
                val txt = cn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                cn.disconnect()
                val content = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                if (content.isNotBlank()) return content
            } catch (e: Exception) { /* пробуем следующего провайдера */ }
        }
        return null
    }

    private fun parse(reply: String): JSONObject? {
        val a = reply.indexOf('{'); val b = reply.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(reply.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (e: Exception) {} }

    // ---------- основной цикл ----------

    private fun loop(c: Context, goal: String, cfg: String?) {
        val hist = ArrayList<String>()
        var lastSig = ""
        var same = 0
        status(c, "Начинаю: " + goal.take(40))
        val m = Regex("(?i)^\\s*(?:пожалуйста[, ]+)?(?:открой|открыть|запусти|запустить|включи приложение|open|launch)\\s+(?:приложение\\s+)?([\\p{L}\\p{N}+ .\\-]{2,40})\\s*[.!]?\\s*$").find(goal)
        if (m != null) {
            val nm = m.groupValues[1].trim()
            val pkg = Apps.find(c, nm)
            if (pkg != null && Apps.openPkg(c, pkg)) {
                var w = 0
                while (w < 6000 && AgentService.inst?.describeScreen()?.pkg != pkg) { sleep(400); w += 400 }
                finish(c, "Открыл " + Apps.label(c, pkg) + "."); return
            }
        }
        var i = 1
        while (i <= MAX_STEPS) {
            if (stopFlag) { finish(c, "Остановлено."); return }
            val svc = AgentService.inst
            if (svc == null) { finish(c, "Доступ к экрану выключен — включи его в Специальных возможностях."); return }

            val scr = svc.describeScreen()
            val sig = scr.pkg + scr.text.hashCode()
            if (sig == lastSig) same++ else { same = 0; lastSig = sig }
            if (same >= 4) { finish(c, "Экран не меняется — остановился, чтобы не ходить по кругу."); return }

            val prompt = "Цель пользователя: $goal\n" +
                "Уже сделано (последние шаги): " + (if (hist.isEmpty()) "ничего" else hist.takeLast(12).joinToString("; ")) + "\n" +
                "Текущее приложение: " + scr.pkg + "\nЭкран:\n" + (if (scr.text.isBlank()) "(пусто или не читается)" else scr.text.take(5500)) +
                "\nВерни JSON следующего шага."
            val reply = llm(cfg, prompt)
            if (reply == null) { finish(c, "Нет связи с ИИ — проверь интернет."); return }
            val j = parse(reply)
            if (j == null) { hist.add("ответ не JSON"); i++; continue }

            val act = j.optString("do").lowercase().trim()
            val arg = j.optString("arg")
            val n = if (j.has("n") && !j.isNull("n")) j.optInt("n", -1) else -1
            val why = j.optString("why")
            val node: Nd? = if (n >= 0 && n < scr.nodes.size) scr.nodes[n] else null
            status(c, "$i. " + act + (if (arg.isNotBlank()) " " + arg.take(30) else if (node != null) " «" + node.label.take(24) + "»" else ""))

            var ok = true
            when (act) {
                "done" -> { finish(c, arg.ifBlank { "Готово." }); return }
                "fail" -> { finish(c, arg.ifBlank { "Не получилось выполнить." }); return }
                "say" -> { emit("say", arg); if (Prefs.b(c, "tts_agent", true)) Speaker.say(arg) }
                "open" -> {
                    val pkg = if (arg.contains('.') && !arg.contains(' ')) arg else Apps.find(c, arg)
                    if (pkg == null) {
                        ok = false
                        hist.add("приложение «" + arg.take(30) + "» не найдено среди установленных — если его нет, выбери fail")
                    } else {
                        ok = Apps.openPkg(c, pkg)
                        var waited = 0
                        while (ok && waited < 6000 && svc.describeScreen().pkg != pkg) { sleep(400); waited += 400 }
                        val now = svc.describeScreen().pkg
                        if (ok && now != pkg) { ok = false; hist.add("открывал " + Apps.label(c, pkg) + ", но на экране " + Apps.label(c, now)) }
                        else if (ok) hist.add("открыто приложение " + Apps.label(c, pkg) + " (" + pkg + ")")
                        sleep(600)
                    }
                }
                "url" -> { ok = Apps.openUri(c, arg); sleep(2300) }
                "tap" -> {
                    val label = node?.label ?: arg
                    if (RISKY.containsMatchIn(label) && Prefs.b(c, "confirm_pay", true)) {
                        val appName = Apps.label(c, scr.pkg)
                        val yes = confirm(c, "Подтвердить действие агента?",
                            "Приложение: $appName\nАгент хочет нажать: «${label.take(60)}»\n" + (if (why.isNotBlank()) "Зачем: $why\n" else "") + "Цель: ${goal.take(80)}",
                            "Да, нажать", "Отмена")
                        if (!yes) { finish(c, "Ты отменил действие «${label.take(40)}» — я его не выполнял."); return }
                    }
                    ok = if (node != null) svc.clickNode(node) else svc.tapText(arg)
                    sleep(1000)
                }
                "type" -> {
                    val field = node
                    val isPwd = (field != null && field.pwd) || svc.focusedIsPassword()
                    val secret = SECRET.containsMatchIn(arg) || (field != null && SECRET.containsMatchIn(field.label))
                    if (isPwd || secret) {
                        val cont = confirm(c, "Нужно ввести данные самому", arg.ifBlank { "Введи пароль, PIN или код вручную, затем нажми «Продолжить»." }.take(160), "Продолжить", "Отмена")
                        if (!cont) { finish(c, "Остановился: нужен ввод пароля или кода вручную."); return }
                    } else {
                        ok = svc.typeInto(field, arg)
                    }
                    sleep(500)
                }
                "enter" -> { ok = svc.imeEnter(); sleep(1200) }
                "scroll" -> {
                    ok = when (arg.lowercase()) {
                        "up" -> svc.scroll(false)
                        "left", "right" -> svc.swipe(arg.lowercase())
                        else -> svc.scroll(true)
                    }
                    sleep(800)
                }
                "back" -> { svc.global(AccessibilityService.GLOBAL_ACTION_BACK); sleep(800) }
                "home" -> { svc.global(AccessibilityService.GLOBAL_ACTION_HOME); sleep(800) }
                "recents" -> { svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS); sleep(900) }
                "notifications" -> { svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); sleep(900) }
                "wait" -> sleep(((arg.toLongOrNull() ?: 2L).coerceIn(1L, 5L)) * 1000L)
                "ask" -> {
                    val cont = confirm(c, "Нужна твоя помощь", arg.ifBlank { "Сделай шаг вручную и нажми «Продолжить»." }.take(200), "Продолжить", "Отмена")
                    if (!cont) { finish(c, "Остановился по твоей просьбе."); return }
                    sleep(600)
                }
                else -> { ok = false }
            }
            hist.add(act + (if (arg.isNotBlank()) " " + arg.take(30) else if (node != null) " «" + node.label.take(24) + "»" else "") + (if (ok) "" else " (не вышло)"))
            i++
        }
        finish(c, "Достиг лимита шагов. Скажи, продолжать ли.")
    }
}
